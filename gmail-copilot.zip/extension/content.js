// Create and inject the floating button
function createFloatingButton() {
    const button = document.createElement('div');
    button.id = 'gmail-copilot-button';
    button.innerHTML = `
        <div class="gmail-copilot-container">
            <button class="gmail-copilot-btn">
                <img src="${chrome.runtime.getURL('icon.png')}" alt="Gmail Copilot" />
            </button>
        </div>
    `;
    document.body.appendChild(button);

    // Add click event handler
    const copilotBtn = button.querySelector('.gmail-copilot-btn');
    copilotBtn.addEventListener('click', handleButtonClick);
}

// Extract email content
function extractEmailContent() {
    const emailContent = document.querySelector('.a3s.aiL');
    if (!emailContent) return null;

    const subject = document.querySelector('h2.hP')?.textContent || '';
    const sender = document.querySelector('.gD')?.textContent || '';
    const body = emailContent.textContent || '';

    return {
        subject,
        sender,
        body
    };
}

// Handle button click
async function handleButtonClick() {
    const emailContent = extractEmailContent();
    if (!emailContent) {
        console.error('Could not extract email content');
        return;
    }

    try {
        const response = await fetch('http://localhost:8000/api/analyze', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(emailContent)
        });

        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }

        const data = await response.json();
        
        // Create and show the response UI
        showResponseUI(data);
    } catch (error) {
        console.error('Error:', error);
        showErrorUI('Failed to analyze email. Please try again.');
    }
}

// Show response UI
function showResponseUI(data) {
    // Remove existing response UI if any
    const existingUI = document.querySelector('.gmail-copilot-response');
    if (existingUI) {
        existingUI.remove();
    }

    // Create response UI
    const responseUI = document.createElement('div');
    responseUI.className = 'gmail-copilot-response';
    responseUI.innerHTML = `
        <div class="gmail-copilot-response-content">
            <h3>Email Summary</h3>
            <p>${data.summary}</p>
            <h3>Suggested Reply</h3>
            <p>${data.reply}</p>
            <button class="gmail-copilot-close">Close</button>
        </div>
    `;

    document.body.appendChild(responseUI);

    // Add close button handler
    const closeBtn = responseUI.querySelector('.gmail-copilot-close');
    closeBtn.addEventListener('click', () => responseUI.remove());
}

// Show error UI
function showErrorUI(message) {
    const errorUI = document.createElement('div');
    errorUI.className = 'gmail-copilot-error';
    errorUI.innerHTML = `
        <div class="gmail-copilot-error-content">
            <p>${message}</p>
            <button class="gmail-copilot-close">Close</button>
        </div>
    `;

    document.body.appendChild(errorUI);

    // Add close button handler
    const closeBtn = errorUI.querySelector('.gmail-copilot-close');
    closeBtn.addEventListener('click', () => errorUI.remove());
}

// Check if we're on an email detail page
function isEmailDetailPage() {
    return window.location.pathname.includes('/mail/u/0/') && 
           !window.location.pathname.includes('/inbox/');
}

// Initialize the extension
function init() {
    if (isEmailDetailPage()) {
        createFloatingButton();
    }
}

// Run initialization
init();

// Listen for URL changes (Gmail is a SPA)
let lastUrl = location.href;
new MutationObserver(() => {
    const url = location.href;
    if (url !== lastUrl) {
        lastUrl = url;
        init();
    }
}).observe(document, { subtree: true, childList: true }); 